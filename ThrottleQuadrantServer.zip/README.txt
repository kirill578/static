if the application does not work:

1. run CMD as administrator and paste: netsh http add urlacl url=http://+:8896/ user=Everyone listen=yes
2. unblock incoming connection on firewall port 8896
3. install latest .net framework